#ifndef __WIRELESS_H_
#define __WIRELESS_H_
extern uint8 DataBuff[10];
float Get_Data(void);
void USART_PID_Adjust(void);

#endif