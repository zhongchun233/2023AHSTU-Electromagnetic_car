#include "headfile.h"
#include "Speed.h"

int16 in_normall_speed = 100;
uint8 MY_element_speed = 0;
int16 final_speed_L = 1;
int16 final_speed_R = 1;
int16 motor_out_max = 8000;
int16 motor_set_max = 8000;
int16 speed_PID_LIMIT = 3000;
int16 normall_LMIT = 3600;
int16 Increase_L = 1;
int16 Increase_R = 1;
  
int16 nowspeed_L = 1;
int16 nowspeed_R = 1;
int16 speed_now = 1;  
int16 Duty_L;
int16 Duty_R;
uint8 run = 1;
//uint8 crossroad = 0;
uint8 normall_speed_flag = 0;            
struct PID speed_PID = { 40 , 1.0 , 0 };
struct PID out_speed_PID = { 50 , 1.0 , 0  };
//struct PID speed_PID = { 40 , 3 , 12 };
//struct PID speed_PID = { 45 , 2 , 7 };
//struct PID speed_PID = { 45 , 2 , 7 };


//struct PID speed_PID = { 50 , 2.8 , 15 };
//struct PID speed_PID = { 50 , 2.8 , 15 };

void getspeed(void);
float PID_Increase_L(int16 ActualSpeed_L,int16 SetSpeed_L);
float PID_Increase_R(int16 ActualSpeed_R,int16 SetSpeed_R);
void Motor_rotation_L(int16 induty_L);
void Motor_rotation_R(int16 induty_R);
//float 	limit_protect(int input,int min,int max);
void   	cal_speed();

void getspeed()    // ��ȡ��������ֵ
{   

	static int16 left_speed = 1;
	static int16 right_speed = 1;

	if(P53 == 0)
	{
			right_speed = ctimer_count_read(CTIM3_P04);
	}
	else
	{
			right_speed = ctimer_count_read(CTIM3_P04);
			right_speed = -right_speed;
	}
	
	if(P35 == 1)
	{
			left_speed = ctimer_count_read(CTIM0_P34);
	}
	else
	{
			left_speed = ctimer_count_read(CTIM0_P34);
			left_speed = -left_speed;
	}
		ctimer_count_clean(CTIM0_P34);  // ����������ֵ���
    ctimer_count_clean(CTIM3_P04);
	

		
//		left_last_speed = left_speed;
	  nowspeed_L *= 0.70;       //һ�׵�ͨ�˲���
	  nowspeed_L += left_speed*0.3; //һ�׵�ͨ�˲���
		
//		right_last_speed = right_speed;
	  nowspeed_R *= 0.70;        //һ�׵�ͨ�˲���
	  nowspeed_R += right_speed*0.3; //һ�׵�ͨ�˲���
  
		speed_now = (nowspeed_L+nowspeed_R)/2;// �ٶ�ƽ��ֵ
//		speed_now = speed_now * 0.0288602; //��������ֵ��1���±������ֱ��ʡ�30�����������֣���68������֣���0.064��3.14�������ܳ�����0.005���ж�ʱ�䣩= 0.0173249595
//nowspeed_R =  right_speed;
//nowspeed_L =  left_speed;

}

void cal_speed_PID(void)
{ 
	int16 abs_servo = abs(servo_place); 
	if(abs_servo<235 )
	{
		out_speed_PID.P = speed_PID.P + 35 * abs_servo /400;
	  out_speed_PID.I = speed_PID.I + 0.2;// + 0.2  * abs_servo /400;
		out_speed_PID.D = speed_PID.D + 15 * abs_servo /400;
		speed_PID_LIMIT = normall_LMIT / 2 + 2200 * abs_servo /400;
		motor_out_max = motor_set_max - 1000 + 1000 * abs_servo /400;
	}else
	{
		out_speed_PID.P = speed_PID.P + 40 * abs_servo /400;
		 out_speed_PID.I = speed_PID.I + 0.5  * abs_servo /400;
		out_speed_PID.D = speed_PID.D + 15 * abs_servo /400;
		speed_PID_LIMIT = normall_LMIT + 2500 * abs_servo /400;
		motor_out_max = motor_set_max + 3000 * abs_servo /400;;//7000 + 3000 * abs_servo /400;
//		if(run == 1 && (flag_block_detected==0 && flag_block_out==0 && flag_block_back==0))
//		{
//			beetime = 10;
//		}
		
	}
}


float PID_Increase_L(int16 ActualSpeed_L,int16 SetSpeed_L)	//����pid����(����ʽpid)
{
    static int16 pre_error_L = 1,last_error_L = 1;
		int16  ierror_L , pidinc_L;
    ierror_L = SetSpeed_L - ActualSpeed_L;

        pidinc_L =  out_speed_PID.P * ( ierror_L - last_error_L )
                 + out_speed_PID.I * ierror_L
                 + out_speed_PID.D *(ierror_L - 2 * last_error_L + pre_error_L);

    last_error_L = ierror_L;   
	
		pre_error_L = last_error_L;

//    last_speed = ActualSpeed_L;
		
        return pidinc_L;
}

float PID_Increase_R(int16 ActualSpeed_R,int16 SetSpeed_R)	//����pid����(����ʽpid)
{
    static int16  pre_error_R = 1,last_error_R = 1;
		int16 ierror_R, pidinc_R;
    ierror_R = SetSpeed_R - ActualSpeed_R;

        pidinc_R =  out_speed_PID.P * ( ierror_R - last_error_R )
                 + out_speed_PID.I * ierror_R
                 + out_speed_PID.D *(ierror_R - 2 * last_error_R + pre_error_R);

	
        last_error_R = ierror_R;	
	
        pre_error_R = last_error_R;

//        last_speed = ActualSpeed_R;

        return pidinc_R;
}
int16 limit(int16 x,int16 min,int16 max)
{
	if(x<min)
	{
		return (min);
	}
	else if(x>max)
	{
		return (max);
	}
	else return (x);
}

void cal_speed(void)
{    

	

//			Increase_L += PID_Increase_L(nowspeed_L,final_speed_L);
//			Increase_R += PID_Increase_R(nowspeed_R,final_speed_R);
				Increase_L = limit(PID_Increase_L(nowspeed_L,final_speed_L),-speed_PID_LIMIT,speed_PID_LIMIT); 
				Increase_R = limit(PID_Increase_R(nowspeed_R,final_speed_R),-speed_PID_LIMIT,speed_PID_LIMIT); 
	
//					Increase_L = PID_Increase_L(nowspeed_L,final_speed_L);
//				Increase_R = PID_Increase_R(nowspeed_R,final_speed_R);
//			
//			if(servo_place > 200 || servo_place <-200)
//			{
//			 Increase_L = limit(PID_Increase_L(nowspeed_L,final_speed_L),-10000,10000);
//			 Increase_R = limit(PID_Increase_R(nowspeed_R,final_speed_R),-10000,10000); 
//			}else
//			{
//			 	Increase_L = limit(PID_Increase_L(nowspeed_L,final_speed_L),-4000,4000); 
//				Increase_R = limit(PID_Increase_R(nowspeed_R,final_speed_R),-4000,4000); 
//			
//			}
			
				Duty_L += Increase_L;
				Duty_R += Increase_R; 
	
				Duty_L = limit(Duty_L,-motor_out_max,motor_out_max);
				Duty_R = limit(Duty_R,-motor_out_max,motor_out_max);


	if( run ==1) //
	{
			Motor_rotation_L(Duty_L);

			Motor_rotation_R(Duty_R);
	}

	else
	{
		Duty_L = 0;
		Duty_R = 0;
		
			Motor_rotation_L(Duty_L);

			Motor_rotation_R(Duty_R);
	}
	
}

void Motor_rotation_R(int16 induty_R)		
{
    if(induty_R >= 0)  
    {

        P60=1;   //�ҵ��ʹ��

        pwm_duty(PWMA_CH2P_P62, induty_R);

    }else
	   {
			 P60=0;

        pwm_duty(PWMA_CH2P_P62, -induty_R);
			 
		 }

}

void Motor_rotation_L(int16 induty_L) 
{
    if(induty_L >= 0) 
    {

        P64=1;    //����ʹ��

        pwm_duty(PWMA_CH4P_P66, induty_L);

    }else   
	   {
			 P64=0;

        pwm_duty(PWMA_CH4P_P66, -induty_L);
			 
		 }
	 

}



void state_analsy() //�ٶ�������
{
	if( //(flag_block_detected == 1 && flag_block_en == 1 ) || flag_block_out == 1 || flag_block_back == 1 || flag_block_adjust == 1 || flag_cir_detected == 1
			flag_angle == 1 
//		&& flag_circ_frc == 0 && flag_circ_out == 0  	&& in_stop == 0
//		&& flag_circ_frcR == 0 && flag_circ_outR == 0
//	  && garage_detected ==0 && in_recogni == 0 && in_detected == 0 && in_cir == 0 
		)	
	{
		beetime =200;
		final_speed_L = in_normall_speed + PID_angle();		
		final_speed_R = in_normall_speed - PID_angle();
	}
	else
	{
	  if(MY_element_speed == 0)
		{
			if(abs_servo > 80)
			{
				final_speed_L =  in_normall_speed - (in_normall_speed * abs_servo) /180 - servo_place;
				final_speed_R =  in_normall_speed - (in_normall_speed * abs_servo) /180 + servo_place;						
			} else{
				final_speed_L =  in_normall_speed - (in_normall_speed * abs_servo) /400 - servo_place;
				final_speed_R =  in_normall_speed - (in_normall_speed * abs_servo) /400 + servo_place;				
			}
 	
			
		}else{
		final_speed_L =  MY_element_speed - (MY_element_speed * abs_servo) /300 - servo_place;
		final_speed_R =  MY_element_speed - (MY_element_speed * abs_servo) /300 + servo_place; 	
		}


	}
}
