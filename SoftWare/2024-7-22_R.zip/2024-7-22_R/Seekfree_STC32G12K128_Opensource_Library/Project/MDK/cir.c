#include "headfile.h"
#include "cir.h"
//uint8 cir_count = 0;
uint8 flag_cir_detected = 0,flag_cir_in = 0 ,flag_cir_out = 0,flag_block_down = 0,flag_ramp_down = 0,R_L_choose = 0;
uint16 cir_detected_cal = 270;
void cir_detected(void)
{
	if((ad[1]+ad[2])>cir_detected_cal && flag_cir_en == 1)
	{
//		static R_L_choose = 0;
		flag_cir_detected = 1;
		flag_cir_en = 0;
		sum_angle = 0;
		if(flag_block_en)
		{
			flag_block_en = 0;
			flag_block_down = 1;
		}
		if(flag_ramp_en)
		{
			flag_ramp_en = 0;
			flag_ramp_down = 1;
		}
	}
}


void cir_in(void)
{ 
	static uint16 cir_count = 0;
	if((flag_cir_detected == 1 || flag_cir_in == 1)||cir_count != 0)
	{
		sum_angle = sum_angle + Actualpal * 0.003;
		if(flag_cir_detected == 1 )
		{   
				Distance_L += nowspeed_L;
				Distance_R += nowspeed_R;
			if(R_L_choose % 2U == 0)    //�������Բ����ͬ�Ƕ�ֵ��Ϊһ������
			{
				aim_angle = 30;//�һ�			
			}else{
				aim_angle = -30;//��						
			}


				flag_angle = 1;
				if(Distance_L > 1500 && Distance_R > 1500)
				{
					MY_element_speed = 135;
					flag_angle = 0; 
					flag_cir_detected = 0;
					flag_cir_in = 1;
					Distance_L = 0;
					Distance_R = 0;
				}
		}
		if(flag_cir_in == 1)
		{ 
//////////////////////�һ�/////////////////////////////			
			if(sum_angle > 334)
			{ 
				MY_element_speed = 0;
				flag_angle = 1; 
				aim_angle = 350;//�һ�
//				aim_angle = -350;//��
				Distance_L += nowspeed_L;
				Distance_R += nowspeed_R;
				beetime = 80;
				if(Distance_L > 4500 && Distance_R > 4500)
				{ sum_angle = 0;
					flag_cir_in = 0;
					flag_angle = 0; 
					Distance_L = 0;
					Distance_R = 0;
					cir_count = 1;
					if(flag_block_down == 1)
					{
						flag_block_en = 1;
						flag_block_down = 0;
					}
					if(flag_ramp_down == 1)
					{
						flag_ramp_en = 1;
						flag_ramp_down = 0;
					}				
				 }
			  }
			}
///////////////////////////////////////////////////////////
			
///////////////////��////////////////////////////////////			
			if(sum_angle < -334)
			{ 
				MY_element_speed = 0;
				flag_angle = 1; 
//				aim_angle = 350;//�һ�
				aim_angle = -350;//��
				Distance_L += nowspeed_L;
				Distance_R += nowspeed_R;
				beetime = 80;
				if(Distance_L > 4500 && Distance_R > 4500)
				{ sum_angle = 0;
					flag_cir_in = 0;
					flag_angle = 0; 
					Distance_L = 0;
					Distance_R = 0;
					cir_count = 1;
					if(flag_block_down == 1)
					{
						flag_block_en = 1;
						flag_block_down = 0;
					}
					if(flag_ramp_down == 1)
					{
						flag_ramp_en = 1;
						flag_ramp_down = 0;
					}				
				}
			}					
////////////////////////////////////////////////////////////		
		if(cir_count != 0)
		{
		 cir_count ++;
			if(cir_count >= 500)
			{  
				R_L_choose ++;
				flag_cir_en = 1;
				cir_count=0;
				beetime = 100;
			}
		
		}
	}
}