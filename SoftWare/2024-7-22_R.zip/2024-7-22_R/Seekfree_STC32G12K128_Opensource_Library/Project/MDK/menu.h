#ifndef __MENU_H_
#define __MENU_H_


#define bee P67
extern uint8 beetime;
extern uint8 page; 
extern uint8 current_page;

void beetimer(void);
extern const char Menu_page[3][8][17];
void BATBEE(void);

void Menu_Select(char strings[3][8][17]);
void Menu_Disp(void);

#endif