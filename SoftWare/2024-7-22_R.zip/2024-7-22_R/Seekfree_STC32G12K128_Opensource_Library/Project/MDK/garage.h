#ifndef __BLOCK_H_
#define __BLOCK_H_

extern uint8 garage_detected;
extern uint8 out_detected;
extern uint8 in_detected;
extern uint8 out_cir;
extern uint8 in_cir;
extern uint8 in_recogni;
extern uint8 in_stop;

extern void Mage();
extern void in_garage();
extern void out_garage();
extern double sum_angle; //�Ƕ��ۼ�
extern float w_angle;  //���ٶ�

void angle();

extern void block_recognition();
extern void block_handler();

extern uint8 flag_block_detected;
extern uint8 flag_block_back;
extern uint8 flag_block_adjust;
extern uint8 flag_block_out;

	
#endif