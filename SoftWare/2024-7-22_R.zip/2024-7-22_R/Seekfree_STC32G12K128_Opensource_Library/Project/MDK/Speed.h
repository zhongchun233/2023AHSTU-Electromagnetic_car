#ifndef __SPEED_H_
#define __SPEED_H_
#define DIR_left P35
#define DIR_right P53 

extern uint8 MY_element_speed;
extern int16 final_speed_L;
extern int16 final_speed_R;
extern int16 nowspeed_L;
extern int16 nowspeed_R;
extern int16 motor_out_max;
extern int16 motor_set_max;
extern int16 normall_LMIT;
extern int16 in_normall_speed;
extern int16 Duty_L;   //ռ�ձ�
extern int16 Duty_R;
extern uint8 run;
extern int16 Increase_R;
extern int16 Increase_L;
extern int16 speed_now;
extern int16 speed_PID_LIMIT;
struct PID{
	float P;
	float I;
	float D;
};
extern struct PID speed_PID,out_speed_PID;


//struct SpeedError{
//        float error;
//        float last_error;  
//        float pre_error;   
//        float last_speed;

//};	//���
//extern struct SpeedError SpeedError_L,SpeedError_R;	//���


extern uint8 normall_speed_flag;
void getspeed();
void cal_speed_PID(void);
float PID_Increase_L(int16 ActualSpeed,int16 SetSpeed);
float PID_Increase_R(int16 ActualSpeed,int16 SetSpeed);
void Motor_rotation_L(int16 induty_L);
void Motor_rotation_R(int16 induty_R);
void state_analsy();
void cal_speed();

#endif