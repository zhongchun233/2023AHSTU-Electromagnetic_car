#ifndef __ADC_H_
#define __ADC_H_


extern float adc_min;
extern float adc_max;
extern float  BAT;
extern float ad[4];
extern float ad_initial[4];


uint16 adc_mean_filter(ADCN_enum ch, ADCRES_enum resolution, uint8 count);
int16 limit(int16 x,int16 min,int16 max);
extern void ad_read();
extern float adc_sort_mean(ADCN_enum ch, ADCRES_enum resolution, uint8 count);


//extern int k;

#endif
