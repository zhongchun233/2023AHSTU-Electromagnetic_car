#include "headfile.h"
#include "key.h"

void keyScan(void)
{
	if(KEY_S1==0)
	{
			if(page < 2)
			{
				page++;
			}
			else
			{
				page = 0;
			}
			
			beetime=10;		
			ips114_clear(WHITE);
		while(1)
			if(KEY_S1==1)
				break;
	} 
	
	if(KEY_S2==0)
	{
		if(page == 1)
		{
		 switch(current_page)
		 {
			 case 0:
						in_normall_speed += 1;
						break;
			 case 1:
						motor_set_max += 100;
						break;
			 case 2:
						distance_detected += 50;
						break;
			 case 3:
						flag_block_en += 1;
						break;
			 case 4:
						flag_cir_en += 1;
						break;
			 case 5:
						flag_ramp_en += 1;
						break;
			 case 6:
						dynamic_PID.P += 2;
						break;
			 case 7:				
						speed_PID.P += 2;
						break;
		 }
		}
				if(page == 2)
		{
		 switch(current_page)
		 {
			 case 0:
						speed_PID.I +=  0.1;
						break;
			 case 1:
						speed_PID.D += 100;
						break;
			 case 2:
						cir_detected_cal += 3;
						break;
			 case 3:
						normall_LMIT += 100;
						break;
//			 case 4:
//						motor_out_max += 100;
//						break;
//			 case 5:
////						motor_out_min += 100;
//						break;
////			 case 6:
////						break;
////				 
////			 case 7:
////						break;
		 }
					 
		}
		
				if(page == 3)
		{
//		 switch(current_page)
//			 case 0:
//						break;
//				 
//			 case 1:
//						break;
//				 
//			 case 2:
//						break;
//				 
//			 case 3:
//						break;
//				 
//			 case 4:
//						break;
//				 
//			 case 5:
//						break;
//				 
//			 case 6: 
//						break;
//				 
//			 case 7: 
//						break;
//				
		}
		
			beetime=10;
//			ips114_clear(WHITE);
		while(1)
			if(KEY_S2==1)
				break;
	}	

	if(KEY_S3==0)
	{
		if(page == 1)
		{
		 switch(current_page)
		 {
			 case 0:
						in_normall_speed -= 1;
						break;
			 case 1:
					  motor_set_max -= 100;
						break;
			 case 2:
						distance_detected -= 50;
						break;
			 case 3:
						flag_block_en -= 1;
						break;
			 case 4:
						flag_cir_en -= 1;
						break;
			 case 5:
						flag_ramp_en -= 1;
						break;
			 case 6:
						dynamic_PID.P -= 2;
						break;
			 case 7:				
						speed_PID.P -= 2;
						break;
		 }
		}
				if(page == 2)
		{
		 switch(current_page)
		 {
			 case 0:
						speed_PID.I -=  0.1; 
						break;
			 case 1:
						speed_PID.D -= 1; 
						break;
			 case 2:
						cir_detected_cal -= 3; 
						break;
			 case 3:
						in_normall_speed -= 100; 
						break;
//			 case 4:
//						motor_out_max -= 100; 
//						break;
//			 case 5:
////						motor_out_min -= 100; 
//						break;
//			 case 6:       
//						break;
//				 
//			 case 7:          
//						break;
		 }		 
		}
		
				if(page == 3)
		{
//		 switch(current_page)
//			{
//			 case 0:       
//						break;
//				 
//			 case 1:     
//						break;
//				 
//			 case 2:      
//						break;
//				 
//			 case 3: 
//						break;
//				 
//			 case 4:   
//						break;
//				 
//			 case 5:   
//						break;
//				 
//			 case 6:  
//						break;
//				 
//			 case 7:  
//						break;
//		}		
		}
		
		beetime=10;
//		ips114_clear(WHITE);
		while(1)
			if(KEY_S3==1)
				break;
	}
	if(KEY_S4==0)
	{
			if(current_page < 7)
			{
				current_page++;
			}
			else
			{
				current_page = 0;
			}
			beetime=10;
//			ips114_clear(WHITE);
			while(1)
			if(KEY_S4==1) break;
	}

}
