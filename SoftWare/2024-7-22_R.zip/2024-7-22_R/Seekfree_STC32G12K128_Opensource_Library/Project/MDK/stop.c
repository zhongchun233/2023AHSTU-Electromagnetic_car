#include "headfile.h"
#include "stop.h"
#include "Speed.h"

uint16 hall_count = 0;
void my_stop()
{	
   if( ad_initial[0] > 100 || ad_initial[1] > 100 || ad_initial[2] > 100 || ad_initial[3] > 100  
        || (flag_block_detected == 1 && flag_block_en == 1) || flag_block_back == 1 || flag_block_out == 1 || flag_block_adjust == 1// ||    hall_flag != 0    
            //&& out_detected == 0 && out_cir == 0
            //&& garage_detected ==0 && in_detected == 0 && in_recogni == 0 && in_cir == 0 && in_stop == 0
            )    
        { 
            run = 1;    //С��ʹ��
         
        }
        else run = 0;    //С��ֹͣ
		
 if( hall_count != 0 )
        {
            static uint8 hall_en = 0;
            hall_count ++; 
//         out_speed_PID = { 50 , 2.8 , 15  };
            if(hall_en == 1)
            {
                    if(nowspeed_L > 15 || nowspeed_R > 15)
                    {
                        motor_out_max = 8000;
                        out_speed_PID.P = 50;
                        out_speed_PID.I = 3;
                        out_speed_PID.D = 15;
                        speed_PID_LIMIT = 3500;    
                    }

                    in_normall_speed = 0;
         
                    if(hall_count >= 200)
                    {
                        hall_count = 201;
                        run = 0;
                    }
            }else{
                    if(hall_count >= 200)
                    {
                        hall_en = 1;
                        hall_count = 0;
                    }
            }
	
		}
	
}