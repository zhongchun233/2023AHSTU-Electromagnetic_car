#include "headfile.h"

float ad_initial[4];	//�������
float ad[4];

float  adc_min = 1;
float  adc_max = 2500;

float  xy_value_L;
float  xy_value_R;
float  BAT = 830;

void ad_read()
{   
			ad_initial[0] = adc_sort_mean(ADC_P00,ADC_12BIT,10); //����		
			ad_initial[1] = adc_sort_mean(ADC_P01,ADC_12BIT,10); // ����ֱ���
			ad_initial[2] = adc_sort_mean(ADC_P05,ADC_12BIT,10); // ����ֱ���
			ad_initial[3] = adc_sort_mean(ADC_P06,ADC_12BIT,10);	// �ҵ��


//			ADC_L = sqrt(ad_initial[0]*ad_initial[0]+ad_initial[1]*ad_initial[1]);
//			ADC_R = sqrt(ad_initial[2]*ad_initial[2]+ad_initial[3]*ad_initial[3]);	
	
		  ad[0] = 100 * (ad_initial[0] - adc_min) / (adc_max - adc_min);  //����	
			ad[1] = 100 * (ad_initial[1] - adc_min) / (adc_max - adc_min);  // ����ֱ���
			ad[2] = 100 * (ad_initial[2] - adc_min) / (adc_max - adc_min);	// ����ֱ���
			ad[3] = 100 * (ad_initial[3] - adc_min) / (adc_max - adc_min);	// �ҵ��

}


uint16 adc_mean_filter(ADCN_enum ch, ADCRES_enum resolution, uint8 count)
{
    uint8 i;
    uint32 sum;

    sum = 0;
    for(i=0; i<count; i++)
    {
        sum += adc_once(ch, resolution);
    }

    sum = sum/count;
    return sum;
}

float adc_sort_mean(ADCN_enum ch, ADCRES_enum resolution, uint8 count)
{
    float adc_read[10];
		float max = 1, min = 1,sum = 0,value;
		int i;
    for ( i = 0; i < count; i++) 
	{
				adc_read[i]	= adc_once(ch, resolution);
        if (max < adc_read[i])
				{  
            max = adc_read[i]; // �������ֵ  
        }
				if (min > adc_read[i])
				{					
            min = adc_read[i]; // ������Сֵ	
				}
			sum += adc_read[i];
	}
	 value = (sum - max - min)/(count - 2);
	return value;
}