#ifndef __STOP_H_
#define __STOP_H_

extern int stop_protect;
extern uint16 hall_count;
void my_stop();


#endif