#include "headfile.h"
#include "menu.h"

uint8 beetime = 0;
uint8 page = 0;
uint8 current_page = 0;
//uint8 pageitem = 1; 
void BATBEE(void)   //�͵�ѹ����
{
	static float BAT_LAST = 1000;
	
	BAT = 0.02 * BAT + 0.98 * BAT_LAST;
	BAT_LAST = BAT;
	if(BAT <= 912)
	{
		beetime = 80; 
	}

}

void beetimer(void)
{
	if(beetime > 0)
	{ 
		 beetime--;
		bee = 1;
	}
	else
	{
		if(0)
		{
		 bee = 1;
		}else
		bee = 0;		
	}
}


const char Menu_page[3][8][17] =
{
  { //page_0
		{"normal_speed"},
    {"motor_set_max"},
  	{"distance    "},
    {"flag_block_en"},
    {"flag_cir_en  "},
    {"flag_ramp_en"},
	  {"dynamic_P    "},
    {"speed_PID.P  "}
	},
	 //page_1
	{ {"speed_PID.I  "},
    {"speed_PID.D  "},
  	{"cir_detected_cal"},
    {"normall_LMIT "},
    {"             "},
    {"             "},
	  {"             "},
    {"             "}
	},
	 //page_2
	{ {"            "},
    {"            "},
  	{"            "},
    {"            "},
    {"            "},
    {"            "},
	  {"            "},
    {"version     "}
	}
	
};

void Menu_Select(char strings[3][8][17])
{
	uint8 i;
	for (i = 0; i < 8; i++)
	{
		if (i == current_page)
		{
			ips114_showstr(2,i,">");
			ips114_showstr(2,i-1," ");
			if(current_page == 0)
			ips114_showstr(2,7," ");	
		}
		
		ips114_showstr(10, i, strings[page - 1][i]);
	}

}

void Menu_Disp(void)
{
	if(page > 0)
	{

	 Menu_Select(Menu_page);
		
		switch((int)page - 1)
		{
			case 0:
				ips114_showfloat(130,0,in_normall_speed,5,2);
				ips114_showfloat(130,1,motor_set_max,5,3);
				ips114_showfloat(130,2,distance_detected,5,2);
				ips114_showfloat(130,3,flag_block_en,5,2);
				ips114_showfloat(130,4,flag_cir_en,5,2);
				ips114_showfloat(130,5,flag_ramp_en,5,2);
				ips114_showfloat(130,6,dynamic_PID.P,5,2);
				ips114_showfloat(130,7,speed_PID.P,5,2);
//				ips114_showfloat(140,7,7.22,5,2);
				break;
			case 1:
				ips114_showfloat(130,0,speed_PID.I,5,2);
				ips114_showfloat(130,1,speed_PID.D,5,2);
				ips114_showfloat(130,2,cir_detected_cal,5,2);
				ips114_showfloat(130,3,normall_LMIT,5,2);
//				ips114_showfloat(140,4,motor_out_max,5,2);
////				ips114_showfloat(140,5,motor_out_min,5,2);
//				ips114_showfloat(140,6,speed_PID.I,5,2);
//				ips114_showfloat(140,7,speed_PID.I,5,2);
				break;
//			case 2:
//				ips114_showfloat(140,0,speed_PID.I,5,2); 
//				ips114_showfloat(140,1,speed_PID.I,5,2);
//				ips114_showfloat(140,2,speed_PID.I,5,2);
//				ips114_showfloat(140,3,speed_PID.I,5,2);
//				ips114_showfloat(140,4,speed_PID.I,5,2);
//				ips114_showfloat(140,5,speed_PID.I,5,2);
//				ips114_showfloat(140,6,speed_PID.I,5,2);
//				ips114_showfloat(140,7,7.22,5,2);
//				break;		
		}
	}
	else
	{

			ips114_showfloat(1,0,ad[0],5,1); // ����
			ips114_showfloat(1,1,ad[1],5,1); // ����ֱ���
			ips114_showfloat(1,2,ad[2],5,1); // ����ֱ���
			ips114_showfloat(1,3,ad[3],5,1); // �ҵ��
		
			ips114_showstr(1,4,"yaw");
			ips114_showfloat(60,4,Actualpal,5,1);	
			ips114_showstr(1,5,"TOF");
			ips114_showfloat(50,5,dl1b_distance_mm,5,0);	
			ips114_showfloat(1,6,Distance_L,5,0);
			ips114_showfloat(50,6,Distance_R,5,0);
			ips114_showfloat(0,7,aim_angle,5,0);
			ips114_showfloat(50,7,flag_angle,5,0);
		
			ips114_showstr(140,0,"speed_now");
			ips114_showint16(120,1,(int)nowspeed_L);
			ips114_showint16(175,1,(int)nowspeed_R);
		  ips114_showstr(130,2,"BAT");
	  	ips114_showfloat(160,2,BAT,5,2);
			ips114_showstr(130,3,"sum_an");
			ips114_showfloat(190,3,sum_angle,5,2);
			ips114_showstr(130,4,"PID_an");
			ips114_showfloat(190,4,PID_angle(),5,2);			
//			ips114_showint16(120,4,(int)final_speed_L);
//			ips114_showint16(180,4,(int)final_speed_R);
			ips114_showstr(120,5,"RUN");
			ips114_showint16(180,5,run);
			ips114_showint16(120,6,(int)final_speed_L);
			ips114_showint16(180,6,(int)final_speed_R);  
			ips114_showstr(130,7,"servo");
			ips114_showint16(180,7,(int)servo_place);
	}
}