#ifndef __KEY_H_
#define __KEY_H_

#define Dip_S1 P75
#define Dip_S2 P76
#define KEY_S1 P70
#define KEY_S2 P71
#define KEY_S3 P72
#define KEY_S4 P73
#define hall P26

void keyScan(void);

#endif
