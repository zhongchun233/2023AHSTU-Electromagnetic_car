#include "headfile.h"
#include "angle.h"

float angle_speed_min = 0;
float angle_speed_max = 2000;
uint8 flag_angle_L = 0;
uint8 flag_angle_R = 0;
float angle_sum_angle;

void angle_detected(void)
{
	if(ad_initial[0]>1500&&ad_initial[1]>250&&ad_initial[2]>2500&&ad_initial[3]>900&&ad_initial[1]<500&&flag_angle_R == 0&&(ad_initial[2]-ad_initial[1])>2000)		
	{
		flag_angle_R = 1;
	}
	else if(ad_initial[3]>1800&&ad_initial[2]>2000&&ad_initial[1]>100&&ad_initial[0]>1800&&ad_initial[1]<500&&flag_angle_L == 0&&(ad_initial[2]-ad_initial[1])>1500)
	{
		flag_angle_L = 1;
	}
}

void angle_handler()
{		
			if(flag_angle_L == 1)//��ֱ��
			{				
				final_speed_L = angle_speed_min;
			  final_speed_R = angle_speed_max;
				angle_sum_angle = angle_sum_angle + imu660ra_gyro_z * 0.005/ 16.384;	
				if(angle_sum_angle > 90)//�����ƫת��75��
				{
					flag_angle_L = 0;
					angle_sum_angle = 0;
				}		
			}
			
			if(flag_angle_R == 1)//��ֱ��
			{
				final_speed_L = angle_speed_max;
				final_speed_R = angle_speed_min;
			  angle_sum_angle = angle_sum_angle + imu660ra_gyro_z * 0.005/ 16.384;	
				if(angle_sum_angle < -90)//���ұ�ƫת��75��
				{
					flag_angle_R = 0;
					angle_sum_angle = 0;
				}
			}
}