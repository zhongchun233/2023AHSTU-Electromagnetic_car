#ifndef __SERVO_H_
#define __SERVO_H_

#define MY_TIMWR 0.003

extern struct PID angle_PID;
extern struct PID dynamic_PID;
extern float s_error;
extern float servo_place;
extern float K_gory;
extern float Actualpal;
extern float Angle_2;
extern int16 abs_servo;
//extern uint8 mid_adc;
//extern uint8 edge_adc;
//void Kalman_Cal_yaw(float acc,float gyro); //�������˲�roll�����		
void PID_servo(void);
float PID_angle(void);
float KalmanFilter(const float ResrcData,float ProcessNiose_Q,float MeasureNoise_R);
void Get_Angle();
#endif