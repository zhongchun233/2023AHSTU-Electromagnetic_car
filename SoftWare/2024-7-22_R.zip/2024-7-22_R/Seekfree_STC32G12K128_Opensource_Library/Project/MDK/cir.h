#ifndef __CIR_H_
#define __CIR_H_

extern uint8 flag_cir_detected ,flag_cir_in ,flag_cir_out ,flag_block_down,flag_ramp_down,R_L_choose;
extern uint16 cir_detected_cal;
void cir_detected(void);
void cir_in(void);


#endif