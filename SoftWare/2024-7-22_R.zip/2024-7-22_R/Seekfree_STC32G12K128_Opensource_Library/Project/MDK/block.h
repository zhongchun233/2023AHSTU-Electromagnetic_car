#ifndef __BLOCK_H_
#define __BLOCK_H_

void block_recognition(void);
void block_handler(void);
void element_en(void);

extern uint8 flag_block_detected;
extern uint8 flag_block_back;
extern uint8 flag_block_adjust;
extern uint8 flag_block_out;
extern uint8 flag_angle;
extern uint8 flag_block_en,flag_cir_en, flag_ramp_en,element_speed;
extern int32 Distance_L , Distance_R ;
extern int16 en_count;
extern uint16 distance_detected;
extern float sum_angle;
extern float aim_angle;

#endif