#ifndef __ANGLE_H_
#define __ANGLE_H_

extern float angle_speed_min;
extern float angle_speed_max;
extern void angle_detected(void);
extern void angle_handler();
extern float angle_sum_angle;	
extern uint8 flag_angle_R;
extern uint8 flag_angle_L;
#endif